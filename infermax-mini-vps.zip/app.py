# Flask server placeholder
print('Server ready!')