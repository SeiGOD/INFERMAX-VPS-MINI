# INFERMAX VPS
This is your brutal simulator playground.