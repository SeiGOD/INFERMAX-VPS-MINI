# Reverse shell simulator
print('Waiting for shell...')